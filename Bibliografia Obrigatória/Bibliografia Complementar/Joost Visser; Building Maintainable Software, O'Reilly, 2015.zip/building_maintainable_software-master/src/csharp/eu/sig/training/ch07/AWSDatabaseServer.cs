﻿namespace eu.sig.training.ch07
{
    public class AWSDatabaseServer : ICloudServer
    {
    }
}
