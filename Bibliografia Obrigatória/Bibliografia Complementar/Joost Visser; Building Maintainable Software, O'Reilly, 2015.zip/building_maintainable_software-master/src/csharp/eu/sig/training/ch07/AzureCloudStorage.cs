﻿namespace eu.sig.training.ch07
{
    public class AzureCloudStorage : ICloudStorage
    {
        public AzureCloudStorage(long sizeGb)
        {
        }
    }
}