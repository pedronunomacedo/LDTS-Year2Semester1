package eu.sig.training.ch07;

public class AzureCloudStorage implements CloudStorage {
    public AzureCloudStorage(@SuppressWarnings("unused") long sizeGb) {}
}