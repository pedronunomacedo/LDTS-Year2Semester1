package eu.sig.training.ch03.withmapandtypes;

import java.awt.Color;
import java.util.List;

// tag::Flag[]
public interface Flag {
    List<Color> getColors();
}
// end::Flag[]