package eu.sig.training.ch06.userservice;

public class NotificationType {

    public static NotificationType fromString(@SuppressWarnings("unused") String type) {
        return new NotificationType();
    }

}
