package eu.sig.training.ch07;

public class AWSDatabaseServer implements CloudServer {

}