package eu.sig.training.ch07;

public class AWSComputeServer implements CloudServer {

}