package eu.sig.training.ch07;

public class AWSCloudStorage implements CloudStorage {

    public AWSCloudStorage(@SuppressWarnings("unused") long sizeGb) {}

}