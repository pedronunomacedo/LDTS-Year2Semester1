package pt.up.fe.ldts.example2;

public interface GraphicFramework {
    void drawLine(double x1, double y1, double x2, double y2);
    void drawCircle(double x, double y, double radius);
}
